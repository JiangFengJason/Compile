int __stdcall testfunc(int agr_1,int agr_2,int agr_3);
int __stdcall answer(int agr_1,int agr_2,int agr_3)
{
	int sum;
	sum = (agr_1+agr_2+agr_3)+testfunc(agr_1,agr_2,agr_3);
	return sum;
}