char _stdcall answer(char agr_1,char agr_2,char agr_3,char agr_4)
{
	char sum;
	sum=agr_2+agr_3+agr_1+agr_4;
	return sum;
}