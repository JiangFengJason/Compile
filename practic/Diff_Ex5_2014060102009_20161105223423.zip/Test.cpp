extern int sum;
void _stdcall answer(int agr_1,int agr_2,int agr_3,int agr_4)
{
	sum=agr_3-agr_4+agr_1-agr_2;
}