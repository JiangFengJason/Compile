extern int sum;
void _cdecl answer(int agr_1,int agr_2,int agr_3)
{
	sum=agr_1-(agr_3-agr_2);
}